package com.example.cubicworld;

import net.minecraftforge.fml.common.Mod;

@Mod("cubicworld")
public class CubicWorldMod {
    public CubicWorldMod() {
        System.out.println("Cubic World carregado!");
    }
}
